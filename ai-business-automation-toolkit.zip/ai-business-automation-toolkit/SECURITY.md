# Security policy

Do not report vulnerabilities publicly. Open a private security advisory in the GitHub repository where available, or contact the repository maintainer through a verified private channel.

Do not include live credentials, customer data, or exploit payloads in public issues.

The API key is a simple server-to-server shared secret. Deploy behind HTTPS, rotate secrets, restrict network access, and add rate limiting and authorization appropriate to your environment.
