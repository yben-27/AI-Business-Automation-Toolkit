from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator


class EventCreate(BaseModel):
    event_id: str = Field(min_length=1, max_length=160)
    source: str = Field(min_length=1, max_length=80)
    event_type: str = Field(min_length=1, max_length=120)
    payload: dict[str, Any]

    @field_validator("event_id", "source", "event_type")
    @classmethod
    def strip_strings(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("Value cannot be blank")
        return value


class EventResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    event_id: str
    source: str
    event_type: str
    payload: dict[str, Any]
    created_at: datetime


class EventIngestResponse(BaseModel):
    event: EventResponse
    duplicate: bool


class LeadQualificationRequest(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    email: str | None = Field(default=None, max_length=254)
    company: str | None = Field(default=None, max_length=160)
    message: str = Field(min_length=1, max_length=5000)
    budget: float | None = Field(default=None, ge=0, le=100_000_000)
    currency: str = Field(default="MAD", min_length=3, max_length=3)


class LeadQualificationResponse(BaseModel):
    score: int
    category: Literal["low", "medium", "high"]
    reasons: list[str]
    recommended_next_step: str


class FollowUpDraftRequest(BaseModel):
    contact_name: str = Field(min_length=1, max_length=120)
    company: str | None = Field(default=None, max_length=160)
    context: str = Field(min_length=1, max_length=3000)
    tone: Literal["professional", "friendly", "formal"] = "professional"
    language: str = Field(default="English", min_length=2, max_length=40)


class FollowUpDraftResponse(BaseModel):
    draft: str
    provider: str
