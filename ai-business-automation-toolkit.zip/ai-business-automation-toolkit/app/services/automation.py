import logging

import httpx

from app.core.config import Settings
from app.schemas import (
    FollowUpDraftRequest,
    FollowUpDraftResponse,
    LeadQualificationRequest,
    LeadQualificationResponse,
)

logger = logging.getLogger(__name__)


def qualify_lead(data: LeadQualificationRequest) -> LeadQualificationResponse:
    """Transparent baseline scoring. Replace/tune these rules using validated sales outcomes."""
    score = 15
    reasons = ["A lead record was submitted."]
    message = data.message.lower()

    if data.email and "@" in data.email:
        score += 10
        reasons.append("A contact email was provided.")
    if data.company:
        score += 10
        reasons.append("A company name was provided.")
    if any(term in message for term in ("need", "looking for", "want to", "automate", "project")):
        score += 20
        reasons.append("The message indicates a potential business need.")
    if any(term in message for term in ("urgent", "this month", "asap", "immediately")):
        score += 15
        reasons.append("The message contains an urgency signal.")
    if data.budget is not None and data.budget > 0:
        score += min(30, 10 + int(data.budget / 5000) * 2)
        reasons.append(f"A budget was stated in {data.currency}.")

    score = min(score, 100)
    category = "high" if score >= 70 else "medium" if score >= 40 else "low"
    next_step = {
        "high": "Prioritize a human review and schedule a discovery call.",
        "medium": "Ask one or two qualifying questions and arrange a follow-up.",
        "low": "Add to a permission-based nurture process; do not assume purchase intent.",
    }[category]

    return LeadQualificationResponse(
        score=score,
        category=category,
        reasons=reasons,
        recommended_next_step=next_step,
    )


def _fallback_draft(data: FollowUpDraftRequest) -> str:
    greeting = f"Hello {data.contact_name},"
    company = f" at {data.company}" if data.company else ""
    return (
        f"{greeting}\\n\\n"
        f"Thank you for taking the time to discuss your needs{company}. "
        f"I wanted to follow up regarding: {data.context}\\n\\n"
        "Would you be available for a short conversation so we can clarify the next steps?\\n\\n"
        "Best regards,"
    )


async def draft_follow_up(
    data: FollowUpDraftRequest, settings: Settings
) -> FollowUpDraftResponse:
    if settings.llm_provider == "rules":
        return FollowUpDraftResponse(draft=_fallback_draft(data), provider="rules")

    if not settings.llm_base_url or not settings.llm_api_key.get_secret_value() or not settings.llm_model:
        raise ValueError("LLM provider requires LLM_BASE_URL, LLM_API_KEY, and LLM_MODEL")

    endpoint = settings.llm_base_url.rstrip("/") + "/chat/completions"
    prompt = (
        "Write a concise business follow-up message. Return only the message, no commentary. "
        "Do not invent facts, discounts, promises, or commitments. "
        f"Language: {data.language}. Tone: {data.tone}. "
        f"Contact: {data.contact_name}. Company: {data.company or 'not specified'}. "
        f"Context: {data.context}"
    )
    headers = {"Authorization": f"Bearer {settings.llm_api_key.get_secret_value()}"}
    body = {
        "model": settings.llm_model,
        "messages": [
            {"role": "system", "content": "You draft accurate, respectful business communications."},
            {"role": "user", "content": prompt},
        ],
        "temperature": 0.4,
    }

    try:
        async with httpx.AsyncClient(timeout=settings.request_timeout_seconds) as client:
            response = await client.post(endpoint, headers=headers, json=body)
            response.raise_for_status()
            result = response.json()
            draft = result["choices"][0]["message"]["content"].strip()
            if not draft:
                raise ValueError("The LLM provider returned an empty draft")
            return FollowUpDraftResponse(draft=draft, provider="openai_compatible")
    except (httpx.HTTPError, KeyError, IndexError, TypeError) as exc:
        logger.exception("LLM follow-up generation failed")
        raise RuntimeError("The configured LLM provider could not generate a draft") from exc
