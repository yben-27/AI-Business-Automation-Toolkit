import logging

from fastapi import APIRouter, Depends, Header, HTTPException, status
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.core.config import Settings, get_settings
from app.db.session import get_db
from app.models.event import AutomationEvent
from app.schemas import (
    EventCreate,
    EventIngestResponse,
    EventResponse,
    FollowUpDraftRequest,
    FollowUpDraftResponse,
    LeadQualificationRequest,
    LeadQualificationResponse,
)
from app.services.automation import draft_follow_up, qualify_lead

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v1")


def require_api_key(
    x_api_key: str | None = Header(default=None),
    settings: Settings = Depends(get_settings),
) -> None:
    expected = settings.api_key.get_secret_value()
    if not x_api_key or x_api_key != expected:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or missing API key",
            headers={"WWW-Authenticate": "ApiKey"},
        )


@router.post(
    "/events",
    response_model=EventIngestResponse,
    dependencies=[Depends(require_api_key)],
    status_code=status.HTTP_202_ACCEPTED,
)
def ingest_event(data: EventCreate, db: Session = Depends(get_db)):
    existing = db.scalar(select(AutomationEvent).where(AutomationEvent.event_id == data.event_id))
    if existing:
        return EventIngestResponse(event=existing, duplicate=True)

    event = AutomationEvent(
        event_id=data.event_id,
        source=data.source,
        event_type=data.event_type,
        payload=data.payload,
    )
    db.add(event)
    try:
        db.commit()
        db.refresh(event)
    except IntegrityError:
        db.rollback()
        existing = db.scalar(
            select(AutomationEvent).where(AutomationEvent.event_id == data.event_id)
        )
        if existing is None:
            raise
        return EventIngestResponse(event=existing, duplicate=True)

    logger.info("automation_event_ingested", extra={"event_id": data.event_id})
    return EventIngestResponse(event=event, duplicate=False)


@router.get(
    "/events",
    response_model=list[EventResponse],
    dependencies=[Depends(require_api_key)],
)
def list_events(limit: int = 50, db: Session = Depends(get_db)):
    if not 1 <= limit <= 200:
        raise HTTPException(status_code=422, detail="limit must be between 1 and 200")
    return list(
        db.scalars(select(AutomationEvent).order_by(AutomationEvent.id.desc()).limit(limit))
    )


@router.post(
    "/leads/qualify",
    response_model=LeadQualificationResponse,
    dependencies=[Depends(require_api_key)],
)
def qualify(data: LeadQualificationRequest):
    return qualify_lead(data)


@router.post(
    "/follow-ups/draft",
    response_model=FollowUpDraftResponse,
    dependencies=[Depends(require_api_key)],
)
async def create_follow_up(
    data: FollowUpDraftRequest,
    settings: Settings = Depends(get_settings),
):
    try:
        return await draft_follow_up(data, settings)
    except ValueError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    except RuntimeError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc
