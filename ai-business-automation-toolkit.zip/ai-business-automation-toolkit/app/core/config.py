from functools import lru_cache

from pydantic import Field, SecretStr, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    app_name: str = "AI Business Automation Toolkit"
    app_env: str = "development"
    log_level: str = "INFO"
    api_key: SecretStr = SecretStr("change-me-in-production")
    database_url: str = "sqlite:///./data/app.db"
    cors_origins: list[str] = Field(
        default_factory=lambda: ["http://localhost:3000", "http://localhost:8000"]
    )
    llm_provider: str = "rules"
    llm_base_url: str = ""
    llm_api_key: SecretStr = SecretStr("")
    llm_model: str = ""
    request_timeout_seconds: float = 20.0

    @field_validator("cors_origins", mode="before")
    @classmethod
    def split_origins(cls, value):
        if isinstance(value, str):
            return [origin.strip() for origin in value.split(",") if origin.strip()]
        return value

    @field_validator("llm_provider")
    @classmethod
    def validate_provider(cls, value: str) -> str:
        if value not in {"rules", "openai_compatible"}:
            raise ValueError("LLM_PROVIDER must be 'rules' or 'openai_compatible'")
        return value

    @field_validator("request_timeout_seconds")
    @classmethod
    def validate_timeout(cls, value: float) -> float:
        if not 1 <= value <= 120:
            raise ValueError("REQUEST_TIMEOUT_SECONDS must be between 1 and 120")
        return value


@lru_cache
def get_settings() -> Settings:
    return Settings()
