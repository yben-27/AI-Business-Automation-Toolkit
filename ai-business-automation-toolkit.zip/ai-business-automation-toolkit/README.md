# AI Business Automation Toolkit

A self-hostable Python API starter for connecting business systems, receiving automation events, qualifying leads, and drafting sales follow-ups.

It is designed as a practical foundation for agencies and small businesses. It is **not** a turnkey autonomous agent platform: connect it to your CRM, forms, WhatsApp provider, or n8n workflows and add business-specific rules before production use.

## Features

- FastAPI REST API with interactive OpenAPI docs.
- API-key authentication for business endpoints.
- Idempotent event intake: repeated `event_id` values are not stored twice.
- SQLite by default; SQLAlchemy URL allows PostgreSQL deployments.
- Rule-based lead qualification that works without an LLM.
- Optional OpenAI-compatible chat-completions adapter (configurable endpoint/model).
- Follow-up draft generation; the API drafts text but never sends messages.
- Structured JSON logs, Docker image, health endpoints, and automated tests.
- Environment-based configuration; secrets are not committed.

## Architecture

```text
Forms / CRM / Webhooks / n8n
           |
           v
    FastAPI + API key
           |
      +----+----------------+
      |                     |
      v                     v
 Event repository     Automation services
 (SQLAlchemy)         - lead qualification
                      - follow-up drafting
                            |
                     Rules engine (default)
                     Optional LLM adapter
```

### Project structure

```text
app/
  api/routes.py          HTTP endpoints
  core/config.py         typed environment settings
  core/logging.py        JSON logging setup
  db/base.py             SQLAlchemy base
  db/session.py          engine and session factory
  models/event.py        persisted event model
  schemas.py             request/response contracts
  services/automation.py business rules and LLM integration
  main.py                application factory and middleware
tests/
  conftest.py
  test_api.py
```

## Quick start (local)

Requirements: Python 3.11+.

```bash
git clone https://github.com/YOUR-USERNAME/ai-business-automation-toolkit.git
cd ai-business-automation-toolkit

python -m venv .venv
# macOS/Linux:
source .venv/bin/activate
# Windows PowerShell:
# .venv\Scripts\Activate.ps1

python -m pip install -e ".[dev]"
cp .env.example .env
```

Edit `.env` and set a strong `API_KEY`. Then run:

```bash
uvicorn app.main:app --reload
```

- API docs: http://127.0.0.1:8000/docs
- Liveness: http://127.0.0.1:8000/health/live
- Readiness: http://127.0.0.1:8000/health/ready

The default SQLite database is created in `./data/app.db`.

## API usage

All `/api/v1/*` endpoints require this header:

```http
X-API-Key: replace-with-your-secret
```

### 1. Receive an automation event

```bash
curl -X POST http://127.0.0.1:8000/api/v1/events \
  -H "Content-Type: application/json" \
  -H "X-API-Key: replace-with-your-secret" \
  -d '{
    "event_id": "website-form-0001",
    "source": "website",
    "event_type": "lead.created",
    "payload": {
      "name": "Sara",
      "email": "sara@example.com",
      "company": "Atlas Services",
      "message": "We need help automating appointment requests."
    }
  }'
```

A repeated `event_id` returns the existing event with `"duplicate": true`, rather than creating another row.

### 2. Qualify a lead

```bash
curl -X POST http://127.0.0.1:8000/api/v1/leads/qualify \
  -H "Content-Type: application/json" \
  -H "X-API-Key: replace-with-your-secret" \
  -d '{
    "name": "Sara",
    "email": "sara@example.com",
    "company": "Atlas Services",
    "message": "We have 12 staff and want to automate appointment bookings and customer follow-ups.",
    "budget": 15000,
    "currency": "MAD"
  }'
```

The default rules engine returns a score, category, and explanation. Scores are heuristic examples; tune them against your actual sales process.

### 3. Draft a follow-up

```bash
curl -X POST http://127.0.0.1:8000/api/v1/follow-ups/draft \
  -H "Content-Type: application/json" \
  -H "X-API-Key: replace-with-your-secret" \
  -d '{
    "contact_name": "Sara",
    "company": "Atlas Services",
    "context": "She asked about automating appointment bookings.",
    "tone": "professional",
    "language": "English"
  }'
```

The result is a draft only. Review it before sending.

## Optional LLM configuration

The default `LLM_PROVIDER=rules` keeps all features functional without an external AI service.

To use an OpenAI-compatible Chat Completions endpoint, set:

```dotenv
LLM_PROVIDER=openai_compatible
LLM_BASE_URL=https://api.openai.com/v1
LLM_API_KEY=your-provider-api-key
LLM_MODEL=your-model-name
REQUEST_TIMEOUT_SECONDS=20
```

The adapter sends a minimal prompt to `/chat/completions`. A provider may retain or process submitted data; review its terms and avoid sending sensitive personal, financial, or confidential data without an appropriate legal basis and safeguards. If the provider is unavailable, the service returns a controlled `502` error rather than silently pretending an AI response was generated.

## Docker

```bash
cp .env.example .env
# Set API_KEY in .env before exposing the service.
docker compose up --build -d
docker compose logs -f api
```

The SQLite database is persisted in the `app_data` Docker volume.

## Tests and quality checks

```bash
pytest
ruff check .
```

Tests use an isolated in-memory SQLite database and do not call external services.

## n8n integration

1. Create an n8n workflow with a Webhook trigger.
2. In the workflow, map the incoming fields to the `POST /api/v1/events` contract.
3. Add the `X-API-Key` header using an n8n credential or secret, not a hard-coded public value.
4. Use the response's `duplicate` flag to avoid repeating downstream actions.
5. For lead qualification, call `POST /api/v1/leads/qualify`.
6. Keep message sending as a separate, explicitly approved workflow step.

Do not expose the API key in browser-side JavaScript or public forms. A public form should submit to a trusted backend or automation platform that holds the secret.

## Production deployment checklist

Before using this with real customers:

- Replace the example API key with a high-entropy secret and rotate it periodically.
- Use HTTPS behind a maintained reverse proxy or managed ingress.
- Prefer PostgreSQL for multi-instance deployments; set `DATABASE_URL` accordingly.
- Run database migrations as a controlled deployment step. This starter creates tables on startup; adopt Alembic before evolving schemas in a production system.
- Add rate limiting, request-size limits, monitoring, alerting, backups, and log retention.
- Restrict CORS to exact trusted origins.
- Add tenant isolation and authorization if serving multiple client businesses.
- Define retention/deletion rules for personal data and confirm applicable privacy obligations (including Moroccan Law 09-08 where relevant).
- Validate webhook signatures at the integration boundary where the source supports them.
- Review AI-generated content; do not automate consequential decisions solely from heuristic scores or model output.
- Pin and scan dependencies in your release pipeline.

## Configuration reference

| Variable | Default | Purpose |
|---|---|---|
| `APP_NAME` | AI Business Automation Toolkit | API title |
| `APP_ENV` | development | Environment label |
| `LOG_LEVEL` | INFO | Logging threshold |
| `API_KEY` | development-only fallback | API authentication secret |
| `DATABASE_URL` | sqlite:///./data/app.db | SQLAlchemy database URL |
| `CORS_ORIGINS` | localhost origins | Comma-separated allowed origins |
| `LLM_PROVIDER` | rules | `rules` or `openai_compatible` |
| `LLM_BASE_URL` | empty | Provider base URL |
| `LLM_API_KEY` | empty | Provider secret |
| `LLM_MODEL` | empty | Provider model name |
| `REQUEST_TIMEOUT_SECONDS` | 20 | External LLM timeout |

## Security notes

This repository is a foundation, not a security certification. The API-key mechanism is suitable for trusted server-to-server integrations when deployed over HTTPS. It is not user authentication, role-based access control, or tenant isolation. Do not put secrets in Git, issue comments, screenshots, or client-side applications.

## Contributing

Issues and pull requests are welcome. Please include tests for behavior changes and never submit real customer data or secrets.

## License

MIT. See [LICENSE](LICENSE).
