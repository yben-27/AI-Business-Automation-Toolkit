def auth():
    return {"X-API-Key": "test-secret"}


def test_health_is_public(client):
    response = client.get("/health/live")
    assert response.status_code == 200
    assert response.json()["status"] == "alive"


def test_api_requires_key(client):
    response = client.get("/api/v1/events")
    assert response.status_code == 401


def test_event_ingest_is_idempotent(client):
    payload = {
        "event_id": "event-001",
        "source": "website",
        "event_type": "lead.created",
        "payload": {"name": "Sara"},
    }
    first = client.post("/api/v1/events", json=payload, headers=auth())
    second = client.post("/api/v1/events", json=payload, headers=auth())

    assert first.status_code == 202
    assert first.json()["duplicate"] is False
    assert second.status_code == 202
    assert second.json()["duplicate"] is True
    assert first.json()["event"]["id"] == second.json()["event"]["id"]


def test_lead_qualification_returns_explanation(client):
    response = client.post(
        "/api/v1/leads/qualify",
        headers=auth(),
        json={
            "name": "Sara",
            "email": "sara@example.com",
            "company": "Atlas",
            "message": "We need to automate this urgently.",
            "budget": 20000,
            "currency": "MAD",
        },
    )
    assert response.status_code == 200
    body = response.json()
    assert body["category"] == "high"
    assert body["score"] >= 70
    assert body["reasons"]


def test_follow_up_draft_works_without_llm(client):
    response = client.post(
        "/api/v1/follow-ups/draft",
        headers=auth(),
        json={
            "contact_name": "Sara",
            "company": "Atlas",
            "context": "Asked about appointment automation",
            "tone": "professional",
            "language": "English",
        },
    )
    assert response.status_code == 200
    assert "Sara" in response.json()["draft"]
    assert response.json()["provider"] == "rules"
