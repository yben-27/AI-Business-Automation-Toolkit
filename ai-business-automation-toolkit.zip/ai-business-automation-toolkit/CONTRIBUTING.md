# Contributing

1. Open an issue describing the problem or proposed change.
2. Create a focused branch from `main`.
3. Add or update tests for behavior changes.
4. Run `ruff check .` and `pytest`.
5. Open a pull request with a concise description and test evidence.

Never commit credentials, customer data, production logs, or personally identifiable information.
