# API examples

The complete interactive API contract is available at `/docs` while the service is running.

## Example n8n event mapping

Map an incoming form payload to:

```json
{
  "event_id": "unique-source-event-id",
  "source": "n8n",
  "event_type": "lead.created",
  "payload": {
    "name": "Contact name",
    "email": "contact@example.com",
    "message": "What the prospect requested"
  }
}
```

Use a stable source event identifier for `event_id`. If the source has no event ID, generate one once in the upstream workflow and preserve it across retries.
