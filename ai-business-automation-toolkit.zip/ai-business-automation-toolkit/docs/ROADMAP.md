# Roadmap

Potential next steps (not implemented in v1.0):

- Alembic database migrations.
- PostgreSQL integration tests and deployment examples.
- Signed webhook verification for supported providers.
- Background job processing with a durable queue.
- Tenant-aware authorization and per-client API keys.
- CRM adapters and opt-in WhatsApp/email delivery integrations.
- Metrics, tracing, and operational dashboards.
- Evaluation datasets for lead-scoring calibration.
